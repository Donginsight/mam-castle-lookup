import { sqliteTable, text, integer, uniqueIndex, index } from 'drizzle-orm/sqlite-core';
import { sql } from 'drizzle-orm';
export const accounts=sqliteTable('accounts',{
 id:text('id').primaryKey(),lookup:text('lookup').notNull().unique(),nameCipher:text('name_cipher').notNull(),password:text('password').notNull(),recovery:text('recovery').notNull(),age:integer('age'),created:integer('created').notNull()
});
export const logins=sqliteTable('logins',{
 token:text('token').primaryKey(),user:text('user').notNull().references(()=>accounts.id),expires:integer('expires').notNull()
},t=>[index('login_user').on(t.user)]);
export const attempts=sqliteTable('attempts',{
 id:text('id').primaryKey(),user:text('user').notNull().references(()=>accounts.id),version:text('version').notNull(),mode:text('mode').notNull(),started:integer('started').notNull(),deadline:integer('deadline').notNull(),finished:integer('finished'),reason:text('reason'),ids:text('ids').notNull(),answers:text('answers').notNull(),memory:text('memory').notNull(),revision:integer('revision').notNull().default(0),score:integer('score'),domains:text('domains'),overlap:integer('overlap').notNull().default(0)
},t=>[index('attempts_user').on(t.user),uniqueIndex('one_active_test').on(t.user).where(sql`${t.finished} IS NULL`)]);
export const limits=sqliteTable('limits',{
 key:text('key').primaryKey(),count:integer('count').notNull(),expires:integer('expires').notNull()
});
