from pathlib import Path
import random,json,itertools,math
from fractions import Fraction

R=Path(__file__).resolve().parents[1];r=random.Random(511012);bank=[]
domains=[('规则与抽象推理','根据模式与多条规则判断'),('视觉空间','旋转、镜像与空间变换'),('数量关系','比例、计数、概率与约束'),('语言逻辑','条件、量词、结论与反例'),('短时记忆操作','短暂呈现后重排和提取'),('注意与编码','准确搜索、比对和编码')]
def F(x):
 x=Fraction(x);return str(x.numerator) if x.denominator==1 else f'{x.numerator}/{x.denominator}'
seen=set()
def add(d,l,kind,stem,opts,a,explain,**extra):
 sig=(d,stem,json.dumps(extra.get('figures')),json.dumps(extra.get('stimulus')))
 count=sum(q['domain']==d and q['level']==l and (d!=0 or q['kind']==kind) for q in bank)
 if sig in seen or count >= (16 if d==0 else 32): return
 seen.add(sig)
 assert len(opts)==4 and len(set(json.dumps(x) for x in opts))==4
 ix=list(range(4));r.shuffle(ix)
 bank.append(dict(id=f'D{d+1}-{sum(q["domain"]==d for q in bank)+1:03}',domain=d,level=l,kind=kind,stem=stem,options=[opts[i] for i in ix],answer=ix.index(a),explain=explain,**extra))
def number(d,l,kind,stem,a,explain,bad):
 vals=[a]
 for b in bad+[a+1,a+2,a+3]:
  if b>=0 and b not in vals:vals.append(b)
  if len(vals)==4:break
 add(d,l,kind,stem,[F(v) for v in vals],0,explain)
def maskgrid(m,n=4):return [[(m>>(y*n+x))&1 for x in range(n)] for y in range(n)]
def rot(m):
 o=0
 for y in range(4):
  for x in range(4):o|=((m>>(y*4+x))&1)<<(x*4+3-y)
 return o
def mirror(m):
 o=0
 for y in range(4):
  for x in range(4):o|=((m>>(y*4+x))&1)<<(y*4+3-x)
 return o
for l in range(1,5):
 for i in range(64):
  while True:
   a,b,c,d=[r.randrange(1,256) for _ in range(4)]
   funcs=[lambda x,y:x^y,lambda x,y:x|y,lambda x,y:x&y,lambda x,y:(x^y)^255]
   k=(l+i)%4;f=funcs[k];target=f(c,d);opts=[target,c,d,255-target]
   if len(set(opts))==4 and len({j for j,g in enumerate(funcs) if g(a,b)==f(a,b)})==1:break
  names=['仅保留两图中恰好出现一次的黑格','保留两图任一图中出现的黑格','仅保留两图共同出现的黑格','保留两图中颜色相同的格子']
  add(0,l,'matrix','每一行中，前两幅图以相同规则产生第三幅图。上下行使用同一规则。第二行缺失的第三幅图应是哪幅？',opts,0,f'第一行显示的规则为：{names[k]}。逐格应用到第二行两图，得到正确选项。注意“恰好一次”和“至少一次”不同。',figures=[a,b,f(a,b),c,d,None],gridWidth=4)
 for i in range(64):
  a=r.randint(2,15);b=r.randint(2,7);c=r.randint(1,6);k=(l+i)%4
  if k==0:
   seq=[a];
   for j in range(5):seq.append(seq[-1]+b+j*c)
   exp=f'相邻差依次是 {"、".join(str(b+j*c) for j in range(5))}，差每次增加 {c}。'
  elif k==1:seq=[a,a+b,a+b+c,a+2*b+c,a+2*b+2*c,a+3*b+2*c];exp=f'增量交替为 {b}、{c}，下一次应继续使用对应的增量。'
  elif k==2:seq=[a,a+b,a*2,a*2+b,a*4,a*4+b];exp=f'奇数位置形成 {a}、{2*a}、{4*a} 的倍增链；偶数位置为同组奇数加 {b}。'
  else:seq=[a+j*b+j*j*c for j in range(6)];exp=f'相邻差每次增加 {2*c}，用最后两次差继续推一步即可。'
  number(0,l,'sequence','在规定的等差增量、交替增量或两条交错数列规则中，选择与前五项一致的延续：\n'+'，'.join(map(str,seq[:5]))+'，？',seq[5],exp+f'下一项是 {seq[5]}。有限数列可有其他构造，本题仅按题干规定的规则类别作答。',[seq[4]+b,seq[5]+c,seq[5]-c,seq[5]+b])
for l in range(1,5):
 for i in range(64):
  while True:
   m=r.randrange(1,65535);k=i%4;turn=l%3+1
   target=m
   if k in [1,3]:target=mirror(target)
   for _ in range(turn):target=rot(target)
   if k in [2,3]:target=mirror(target)
   wrong=[m,mirror(m),rot(m),rot(rot(m)),rot(rot(rot(m))),mirror(rot(m)),mirror(rot(rot(m))),mirror(rot(rot(rot(m))))]
   wrong=list(dict.fromkeys(x for x in wrong if x!=target))
   if len(wrong)>=3:break
  action=('先左右镜像，再' if k in [1,3] else '')+f'顺时针旋转 {turn*90} 度'+('，再左右镜像' if k in [2,3] else '')
  add(1,l,'spatial',f'对给定方格图执行：{action}。上下左右均以屏幕为准。结果是哪幅图？',[target]+r.sample(wrong,3),0,'按顺序执行变换。左右镜像将每行反向；顺时针 90 度将坐标（行、列）变为（列、3−行）。旋转与镜像通常不能交换顺序。',figures=[m],gridWidth=4)
for l in range(1,5):
 for i in range(64):
  k=i%4;a=r.randint(4,20);b=r.randint(3,12);c=r.randint(2,9)
  if k==0:
   n=a+b;c=min(c,min(a,b)-1);p=Fraction(2*a*b,n*(n-1))
   number(2,l,'probability',f'袋内有 {a} 枚白筹码和 {b} 枚黑筹码。每枚等概率，连续抽两枚且不放回。恰好一白一黑的概率是多少？',p,f'先白后黑和先黑后白两条路径都要算。概率＝2×{a}×{b}÷[{n}×{n-1}]＝{F(p)}。第二次分母减少 1。',[p/2,Fraction(2*a*b,n*n),Fraction(a,n)])
  elif k==1:
   n=a+b-c;v=min(a,b);lower=max(0,a+b-n)
   number(2,l,'sets',f'共有 {n} 人。完成任务 A 的有 {a} 人，任务 B 的有 {b} 人。未给出实际重叠情况。至少有多少人两项都完成？',lower,f'两组人数相加为 {a+b}，超过总人数 {n} 的部分必须重叠，所以交集至少 {lower} 人。不是说实际重叠就一定等于该下界。',[v,lower+1,lower+2])
  elif k==2:
   p=Fraction(a,a+b);gain=10+c*4;loss=2+b;ev=p*gain-(1-p)*loss
   # allow negative numeric answers here
   opts=[ev,ev+1,ev-1,ev+2]
   add(2,l,'expectation',f'某方案成功概率为 {F(p)}，成功得 {gain} 分，失败扣 {loss} 分。重复很多次后的平均每次净得分是多少？',[F(x) for x in opts],0,f'扣分作为负数。期望＝{F(p)}×{gain}−{F(1-p)}×{loss}＝{F(ev)}。这不保证每一次实际得分。')
  else:
   A=a;B=b;C=c;D=r.randint(3,14);E=r.randint(2,8);v=max(A+C,B+D)+E
   number(2,l,'schedule',f'人员充足，任务可并行。A 用 {A} 分钟、B 用 {B} 分钟，都可立即开始；C 用 {C} 分钟，等 A 完成；D 用 {D} 分钟，等 B 完成；E 用 {E} 分钟，等 C、D 都完成。全部最早几分钟结束？',v,f'A→C 链共 {A+C} 分钟，B→D 链共 {B+D} 分钟。E 需等待较长链，故总时长＝{max(A+C,B+D)}+{E}＝{v}。',[A+B+C+D+E,min(A+C,B+D)+E,v+1])
properties=['完成校验','拥有授权','获得通行证','提交记录','参加复核','达到门槛','通过培训','完成登记']
for l in range(1,5):
 for i in range(64):
  A,B,C=r.sample(properties,3);k=i%4;person=r.choice(['甲','乙','丙','丁'])
  if k==0:
   stem=f'规则：所有{A}的人都{B}；所有{B}的人都{C}。已知{person}没有{C}。哪项一定成立？';opts=[f'{person}没有{A}',f'{person}有{A}',f'只有{A}的人才能{C}',f'没有{A}的人都没有{C}'];e=f'A→B→C，因此非 C→非 B→非 A。把箭头倒过来，或者把“非 A”直接推成“非 C”，都不成立。'
  elif k==1:
   stem=f'原句：“所有{A}的人都{B}。”下列哪句话与原句的否定完全等价？';opts=[f'至少有一人{A}但没有{B}',f'所有{A}的人都没有{B}',f'至少有一人{B}但没有{A}',f'没有{A}的人都{B}'];e='否定“所有”，只需存在一个满足前件而不满足后件的反例；不必要求所有人都违反。'
  elif k==2:
   stem=f'规则：{A}或{B}至少一项成立；如果{A}，则{C}；如果{B}，也{C}。哪项一定成立？';opts=[C,f'{A}且{B}',f'没有{A}',f'只有{C}才能{A}'];e='按 A、B 两种可能分情况。不论哪条路径成立，都通向 C。至少一项成立不保证两项都成立；C 的逆向关系也未给出。'
   # fourth option must not restate A -> C
   opts[3]=f'{C}的人一定{A}'
  else:
   stem=f'只有{A}，才允许{B}；{person}已经{B}。同时，一些{A}的人{C}。哪项一定成立？';opts=[f'{person}{A}',f'{person}{C}',f'所有{A}的人都{B}',f'{person}没有{C}'];e='“只有 A 才 B”是 B→A。部分 A 具有 C，无法确定当前这位是否属于该部分；不能由部分概括全部。'
  add(3,l,'verbal',stem,opts,0,e)
for l in range(1,5):
 for i in range(64):
  n=3+l+(i%2);seq=[r.randrange(10) for _ in range(n)];k=i%4
  if k==0:target=seq[::-1];ask='按相反顺序选择刚才的数字';e='从最后一位开始向前提取，不能仅把相邻两位交换。'
  elif k==1:target=sorted(seq);ask='将刚才的数字按从小到大排列（重复数字保留）';e='逐个提取并排序；保留重复数字，不能当作集合去重。'
  elif k==2:target=seq[1::2]+seq[::2];ask='先按原顺序列出第 2、4、6……位，再列出第 1、3、5……位';e='这里按位置的奇偶重排，而不是按数字本身奇偶分组。'
  else:target=[(x+1)%10 for x in seq];ask='顺序不变，每位数字加 1；9 变成 0';e='每位独立加 1，9 回到 0，不向前一位进位。'
  txt=lambda s:' '.join(map(str,s));opts=[txt(target)];wrong=[seq,seq[::-1],sorted(seq,reverse=True),seq[1:]+seq[:1],[ (x+2)%10 for x in seq]]
  for w in wrong:
   if txt(w) not in opts:opts.append(txt(w))
   if len(opts)==4:break
  while len(opts)<4:
   w=[r.randrange(10) for _ in seq]
   if txt(w) not in opts:opts.append(txt(w))
  add(4,l,'memory',ask+'。不要抄写、截图或使用外部工具。',opts,0,f'呈现序列：{txt(seq)}。正确结果：{txt(target)}。{e}',stimulus=seq,presentationMs=len(seq)*1100+1500)
for l in range(1,5):
 for i in range(64):
  n=20+l*8;k=i%4
  if k<2:
   chars=[r.choice('PQBD0698') for _ in range(n)];target=r.choice('PQBD0698');v=chars.count(target)
   if k==0:stem=f'准确数出下列字符中“{target}”的出现次数。\n'+' '.join(chars);e=f'逐个比对目标字符 {target}，共有 {v} 个。注意外形相近字符不计入。'
   else:
    v=sum(chars[j]==target and chars[j-1] in '0698' for j in range(1,n));stem=f'数出“{target}”的出现次数，但只计入它前面紧挨着一个数字（0、6、9、8）的情况。首位不计。\n'+' '.join(chars);e=f'同时满足字符匹配和前一位是数字才计数，共 {v} 个。只数目标总次数会多算。'
   number(5,l,'attention',stem,v,e,[max(0,v-1),v+1,v+2])
  else:
   keys=r.sample(list('ABCDEFGH'),5);digits=r.sample(range(10),5);mapping=dict(zip(keys,digits));seq=[r.choice(keys) for _ in range(5+l)];output=[mapping[x] for x in seq]
   if k==3:output=output[::-1]
   ans=' '.join(map(str,output));opts=[ans];wrong=[output[::-1],[(x+1)%10 for x in output],output[1:]+output[:1],[(x+2)%10 for x in output]]
   for w in wrong:
    t=' '.join(map(str,w))
    if t not in opts:opts.append(t)
    if len(opts)==4:break
   add(5,l,'coding','编码规则：'+'，'.join(f'{x}→{mapping[x]}' for x in keys)+'。\n字符序列：'+' '.join(seq)+'。\n'+('先逐字转换，再把完整结果倒序。' if k==3 else '按原顺序逐字转换。')+'正确输出是什么？',opts,0,'逐个查表，不能凭相似外形猜测。'+('题目还要求最后倒序。' if k==3 else '')+f'结果为 {ans}。')
assert len(bank)==768
assert all(sum(q['domain']==d and q['level']==l for q in bank)==32 for d in range(6) for l in range(1,5))
assert len({q['id'] for q in bank})==768
# Conditions are design tiers, not empirically calibrated difficulty.
(R/'lib/bank.json').write_text(json.dumps({'version':'research-1','domains':[{'id':i,'name':x[0],'desc':x[1]} for i,x in enumerate(domains)],'questions':bank},ensure_ascii=False,separators=(',',':')))
print('Generated 768 tasks; 6 domains × 4 design tiers × 32 variants. Not normed IQ.')
