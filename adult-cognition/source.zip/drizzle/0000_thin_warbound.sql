CREATE TABLE `accounts` (
	`id` text PRIMARY KEY NOT NULL,
	`lookup` text NOT NULL,
	`name_cipher` text NOT NULL,
	`password` text NOT NULL,
	`recovery` text NOT NULL,
	`age` integer,
	`created` integer NOT NULL
);
--> statement-breakpoint
CREATE UNIQUE INDEX `accounts_lookup_unique` ON `accounts` (`lookup`);--> statement-breakpoint
CREATE TABLE `attempts` (
	`id` text PRIMARY KEY NOT NULL,
	`user` text NOT NULL,
	`version` text NOT NULL,
	`mode` text NOT NULL,
	`started` integer NOT NULL,
	`deadline` integer NOT NULL,
	`finished` integer,
	`reason` text,
	`ids` text NOT NULL,
	`answers` text NOT NULL,
	`memory` text NOT NULL,
	`revision` integer DEFAULT 0 NOT NULL,
	`score` integer,
	`domains` text,
	`overlap` integer DEFAULT 0 NOT NULL,
	FOREIGN KEY (`user`) REFERENCES `accounts`(`id`) ON UPDATE no action ON DELETE no action
);
--> statement-breakpoint
CREATE INDEX `attempts_user` ON `attempts` (`user`);--> statement-breakpoint
CREATE UNIQUE INDEX `one_active_test` ON `attempts` (`user`) WHERE "attempts"."finished" IS NULL;--> statement-breakpoint
CREATE TABLE `limits` (
	`key` text PRIMARY KEY NOT NULL,
	`count` integer NOT NULL,
	`expires` integer NOT NULL
);
--> statement-breakpoint
CREATE TABLE `logins` (
	`token` text PRIMARY KEY NOT NULL,
	`user` text NOT NULL,
	`expires` integer NOT NULL,
	FOREIGN KEY (`user`) REFERENCES `accounts`(`id`) ON UPDATE no action ON DELETE no action
);
--> statement-breakpoint
CREATE INDEX `login_user` ON `logins` (`user`);