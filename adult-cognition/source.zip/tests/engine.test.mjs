import assert from 'node:assert/strict';
import { DatabaseSync } from 'node:sqlite';
import fs from 'node:fs';
import {engine,exportWorkbook,chooseForm,grade,average,hashPassword} from '../lib/engine.mjs';
import BANK from '../lib/bank.json' with {type:'json'};
const sqlite=new DatabaseSync(':memory:');sqlite.exec(fs.readFileSync(new URL('../drizzle/0000_thin_warbound.sql',import.meta.url),'utf8'));
class Stmt{constructor(sql,params=[]){this.sql=sql;this.params=params;}bind(...p){return new Stmt(this.sql,p);}async first(){return sqlite.prepare(this.sql).get(...this.params)||null;}async all(){return {results:sqlite.prepare(this.sql).all(...this.params)};}async run(){const r=sqlite.prepare(this.sql).run(...this.params);return {meta:{changes:Number(r.changes)}};}}
const env={DB:{prepare:s=>new Stmt(s),batch:async statements=>{sqlite.exec('BEGIN');try{const out=[];for(const s of statements)out.push(await s.run());sqlite.exec('COMMIT');return out;}catch(e){sqlite.exec('ROLLBACK');throw e;}}},COGNITION_KEY:'a1'.repeat(32)};
let now=1791816000000;
async function req(op,data={},cookie='',method='POST',origin='https://example.test'){const url='https://example.test/api/engine'+(method==='GET'?'?op='+op+(data.id?'&id='+data.id:''):'');const headers={'Content-Type':'application/json',Origin:origin,Cookie:cookie,'cf-connecting-ip':'test'};const r=await engine(new Request(url,{method,headers,...(method==='POST'?{body:JSON.stringify({op,...data})}:{})}),env,now);const d=await r.json();return {r,d,cookie:r.headers.get('set-cookie')?.split(';')[0]};}
assert.equal(BANK.questions.length,768);
const signatures=BANK.questions.map(q=>JSON.stringify([q.domain,q.stem,q.figures??null,q.stimulus??null]));assert.equal(new Set(signatures).size,768);
for(const q of BANK.questions){assert.equal(q.options.length,4);assert.equal(new Set(q.options.map(JSON.stringify)).size,4);assert(q.answer>=0&&q.answer<4&&q.explain.length>20);}
for(let run=0;run<20;run++){const ids=chooseForm();assert.equal(ids.length,144);assert.equal(new Set(ids).size,144);for(let d=0;d<6;d++)for(let l=1;l<=4;l++)assert.equal(ids.filter(id=>{let q=BANK.questions.find(q=>q.id===id);return q.domain===d&&q.level===l;}).length,6);}
const first=chooseForm(),second=chooseForm(first);assert(!second.some(id=>first.includes(id)));
assert.equal(grade(first,{}).score,0);const correct=Object.fromEntries(first.map(id=>[id,BANK.questions.find(q=>q.id===id).answer]));assert.equal(grade(first,correct).score,100);
const pw='test-only-strong-long-passphrase';const hashed=await hashPassword(pw);assert(hashed.startsWith('scrypt$32768$8$3$'));assert.notEqual(hashed,await hashPassword(pw));
let x=await req('register',{username:'test_alpha',password:pw,age:51,consent:true});assert.equal(x.r.status,201);const aCookie=x.cookie,recovery=x.d.recovery;assert(/Secure; HttpOnly; SameSite=Strict/.test(x.r.headers.get('set-cookie')));assert.equal(recovery.length,48);
const stored=sqlite.prepare('SELECT * FROM accounts').get();assert(!stored.password.includes(pw));assert(!stored.name_cipher.includes('test_alpha'));assert(!stored.lookup.includes('test_alpha'));assert.notEqual(stored.recovery,recovery);
x=await req('register',{username:'test_beta',password:pw,age:null,consent:true});assert.equal(x.r.status,201);const bCookie=x.cookie;
assert.equal((await req('account',{},'', 'GET')).r.status,401);
assert.equal((await req('register',{username:'test_gamma',password:pw,age:null,consent:true},'','POST','https://evil.test')).r.status,403);
assert.equal((await req('login',{username:'test_alpha',password:'wrong'})).r.status,401);
x=await req('login',{username:'TEST_ALPHA',password:pw});assert.equal(x.r.status,200);
x=await req('start',{mode:'formal',ready:true},aCookie);assert.equal(x.r.status,201);let a=x.d.attempt;assert.equal(a.questions.length,144);assert.equal(a.deadline-a.started,7200000);assert(a.questions.every(q=>!('answer'in q)&&!('explain'in q)&&!('stimulus'in q)));assert(a.questions.filter(q=>q.kind==='memory').every(q=>!('options'in q)));
assert.equal((await req('result',{id:a.id},aCookie,'GET')).r.status,409);assert.equal((await req('result',{id:a.id},bCookie,'GET')).r.status,404);
x=await req('start',{mode:'formal',ready:true},aCookie);assert.equal(x.d.attempt.id,a.id);
let q=a.questions.find(q=>q.kind!=='memory');let answer=BANK.questions.find(z=>z.id===q.id).answer;
x=await req('answer',{id:a.id,question:q.id,choice:answer,revision:a.revision},aCookie);assert.equal(x.r.status,200);a.revision=x.d.revision;
assert.equal((await req('answer',{id:a.id,question:q.id,choice:0,revision:0},aCookie)).r.status,409);
const mq=a.questions.find(q=>q.kind==='memory');assert.equal((await req('answer',{id:a.id,question:mq.id,choice:0,revision:a.revision},aCookie)).r.status,409);
x=await req('memory',{id:a.id,question:mq.id},aCookie);assert.equal(x.d.stage,'present');assert(!x.d.question);const reveal=x.d.revealAt;a.revision=x.d.revision;
now=reveal-1;assert.equal((await req('memory',{id:a.id,question:mq.id},aCookie)).d.stage,'present');now=reveal+1;x=await req('memory',{id:a.id,question:mq.id},aCookie);assert.equal(x.d.stage,'answer');assert(!('stimulus'in x.d));assert(!('answer'in x.d.question));
x=await req('account',{},aCookie,'GET');assert.equal(x.d.active.deadline,a.deadline);assert.equal(x.d.active.answers[q.id],answer);
now=a.deadline+1;assert.equal((await req('answer',{id:a.id,question:q.id,choice:0,revision:a.revision},aCookie)).r.status,409);x=await req('result',{id:a.id},aCookie,'GET');assert.equal(x.d.attempt.reason,'timeout');assert.equal(x.d.attempt.answered,1);assert.equal(x.d.attempt.score,0.69);
assert.equal((await req('answer',{id:a.id,question:q.id,choice:0,revision:a.revision},aCookie)).r.status,409);
// Practice tests don't pollute formal averages.
x=await req('start',{mode:'practice',ready:true},aCookie);assert.equal(x.d.attempt.questions.length,24);const practice=x.d.attempt;await req('finish',{id:practice.id},aCookie);
x=await req('account',{},aCookie,'GET');assert.equal(x.d.averages.count,1);assert.equal(x.d.averages.all,0.69);assert.equal(x.d.averages.recentCount,1);
const rows=[{mode:'formal',version:'research-1',finished:1,score:9000},{mode:'formal',version:'research-1',finished:1,score:6000},{mode:'formal',version:'research-1',finished:1,score:3000},{mode:'formal',version:'research-1',finished:1,score:0},{mode:'practice',version:'research-1',finished:1,score:10000}];assert.equal(average(rows).all,45);assert.equal(average(rows).recent,60);assert.equal(average(rows).count,4);
const exported=await exportWorkbook(new Request('https://example.test/api/export',{headers:{Cookie:aCookie}}),env,now);assert.equal(exported.status,200);const bytes=new Uint8Array(await exported.arrayBuffer());assert.equal(bytes[0],80);assert.equal(bytes[1],75);fs.writeFileSync(new URL('../tests/results-test.xlsx',import.meta.url),bytes);
// Account recovery invalidates all previous sessions; reset returns no password/recovery value.
x=await req('recover',{username:'test_alpha',recovery,password:'changed-test-only-password'},aCookie);assert.equal(x.r.status,200);assert.equal((await req('account',{},aCookie,'GET')).r.status,401);assert.equal((await req('login',{username:'test_alpha',password:'changed-test-only-password'})).r.status,200);
console.log('PASS: 768 unique tasks; 144-item stratified forms; unseen prioritization; score arithmetic; salted slow hash/encrypted handle; register/login; origin guard; private records; no pre-test answer leakage; memory timing; immutable server deadline; stale revision rejection; expiry and blanks; practice exclusion; all/recent averages; recovery; XLSX export.');
