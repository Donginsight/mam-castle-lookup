import { env } from 'cloudflare:workers';
import { exportWorkbook } from '../../../lib/engine.mjs';
export const dynamic='force-dynamic';
export async function GET(request:Request){return exportWorkbook(request,env);}
