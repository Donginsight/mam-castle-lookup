import { env } from 'cloudflare:workers';
export const dynamic='force-dynamic';
export async function GET(){try{await env.DB.prepare('SELECT 1 FROM accounts LIMIT 1').first();return Response.json({ok:true,version:'research-1',bankCount:768},{headers:{'Cache-Control':'no-store'}});}catch{return Response.json({ok:false},{status:503});}}
