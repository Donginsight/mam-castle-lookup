import { env } from 'cloudflare:workers';
import { engine } from '../../../lib/engine.mjs';
export const dynamic='force-dynamic';
export async function GET(request:Request){return engine(request,env);}
export async function POST(request:Request){return engine(request,env);}
