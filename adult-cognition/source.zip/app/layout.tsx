import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "思维刻度 · 成人认知自测研究版",
  description: "免费注册，六类任务、768道题库变式、120分钟随机测试。在线记录与Excel导出；任务成绩不是IQ。",
  icons: {
    icon: "/favicon.svg",
    shortcut: "/favicon.svg",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="zh-CN">
      <body className="antialiased">{children}</body>
    </html>
  );
}
